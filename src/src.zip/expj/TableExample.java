package expj;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class TableExample extends JFrame {

    public TableExample() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);

        // 스크롤 패널을 생성합니다.
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 10, 464, 340);
        getContentPane().add(scrollPane);

        // 테이블을 생성하고 스크롤 패널에 추가합니다.
        JTable table = new JTable();
        scrollPane.setViewportView(table);

        // 테이블 모델을 설정합니다.
        DefaultTableModel model = new DefaultTableModel(
                new Object[][]{
                        {"1", "Apple"},
                        {"2", "Banana"},
                        {"3", "Orange"}
                },
                new String[]{"ID", "Fruit"}
        );
        table.setModel(model);

        // 테이블의 배경색을 노란색으로 설정합니다.
        table.setBackground(Color.YELLOW);

        // 스크롤 패널의 뷰포트의 배경색을 노란색으로 설정합니다.
        JViewport viewport = scrollPane.getViewport();
        viewport.setBackground(Color.YELLOW);

        // 테이블 헤더의 배경색을 빨간색으로 설정하고 글자를 중앙 정렬합니다.
        JTableHeader header = table.getTableHeader();
        header.setBackground(Color.RED);
        header.setForeground(Color.WHITE);
        DefaultTableCellRenderer renderer = (DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer();
        renderer.setHorizontalAlignment(JLabel.CENTER);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            TableExample frame = new TableExample();
            frame.setVisible(true);
        });
    }
}
