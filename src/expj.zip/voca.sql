-- 단어 추가
CREATE TABLE words (
    id NUMBER(10) PRIMARY KEY,
    korean VARCHAR2(100) NOT NULL,    
    english VARCHAR2(100) NOT NULL,
    list_id NUMBER(10),
    FOREIGN KEY (list_id) REFERENCES word_lists(id)
);
CREATE SEQUENCE words_seq
    START WITH 1
    INCREMENT BY 1
    NOMAXVALUE;
SELECT * FROM  words ;
INSERT INTO words (id, korean, english, list_id) VALUES (words_seq.NEXTVAL, '에이', 'a', 1);
INSERT INTO words (id, korean, english, list_id) VALUES (words_seq.NEXTVAL, '비', 'b', 1);

INSERT INTO words (id, korean, english, list_id) VALUES (words_seq.NEXTVAL, '에프', 'f', 2);
INSERT INTO words (id, korean, english, list_id) VALUES (words_seq.NEXTVAL, '지', 'g', 2);

drop sequence words_seq;
DROP TABLE words;

-- 그룹 추가
CREATE TABLE word_lists (
    id NUMBER(10) PRIMARY KEY,
    category VARCHAR2(50) NOT NULL
);
drop sequence word_lists_seq;
DROP TABLE word_lists;
CREATE SEQUENCE word_lists_seq
    START WITH 1
    INCREMENT BY 1
    NOMAXVALUE;
SELECT category FROM word_lists;
INSERT INTO word_lists (id, category) VALUES (word_lists_seq.NEXTVAL, '초등단어');
INSERT INTO word_lists (id, category) VALUES (word_lists_seq.NEXTVAL, '중등단어');


COMMIT;