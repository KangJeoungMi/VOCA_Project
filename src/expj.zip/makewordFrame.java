package expj;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JCheckBoxMenuItem;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Button;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;

public class makewordFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField2;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					makewordFrame frame = new makewordFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public makewordFrame() {
		setTitle("단어 만들기");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 402, 311);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("메인으로");
		btnNewButton.setBounds(261, 239, 97, 23);
		contentPane.add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(102, 43, 238, 23);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField2 = new JTextField();
		textField2.setColumns(10);
		textField2.setBounds(102, 76, 238, 23);
		contentPane.add(textField2);
		
		JLabel lblNewLabel = new JLabel("한국어");
		lblNewLabel.setBounds(46, 43, 59, 23);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabe2 = new JLabel("영어");
		lblNewLabe2.setBounds(46, 76, 59, 23);
		contentPane.add(lblNewLabe2);
		
		Choice choice = new Choice();
		choice.setForeground(Color.PINK);
		choice.setBounds(46, 16, 183, 21);
		contentPane.add(choice);
		
		JButton btnSend = new JButton("등록");
		btnSend.setBounds(37, 239, 97, 23);
		contentPane.add(btnSend);
		
		JButton btnG = new JButton("그룹 추가");
		btnG.setBounds(243, 14, 97, 23);
		contentPane.add(btnG);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(46, 109, 312, 126);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				 "korean","English"
			}
		));
		
		JButton btnNewButton_1_2 = new JButton("저장");
		btnNewButton_1_2.setBounds(146, 239, 97, 23);
		contentPane.add(btnNewButton_1_2);
		
		// 메인 이동 버튼
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				wordmainFrame WM = new wordmainFrame();
				WM.setVisible(true);
				dispose();
			}
		});
		
		// 그룹 추가 페이지 이동 버튼
		btnG.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddCate ac = new AddCate();
				ac.setVisible(true);
			}
		});
		
		// 등록버튼 
		btnSend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(textField.getText().equals("")|| textField2.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "단어를 입력하세요", "정보", JOptionPane.INFORMATION_MESSAGE);
				}else {
					String data[] = {textField.getText(),textField2.getText()};
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					model.addRow(data);
					JOptionPane.showMessageDialog(null, "등록되었습니다", "정보", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		
		//저장버튼
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() == 0) {
					JOptionPane.showMessageDialog(null, "저장 할 단어가 없습니다", "정보", JOptionPane.INFORMATION_MESSAGE);
				}else {
					// 데이터베이스 연동
					String English,Korean;
					try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
						Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "ADAM", "1234");
						for (int i=0;i<model.getRowCount(); i++) {
							English = model.getValueAt(i, 0).toString();
							Korean = model.getValueAt(i, 1).toString();
							String sql = "INSERT INTO words (id, korean, english, list_id) VALUES (words_seq.NEXTVAL, ?, ?, ?)";

							PreparedStatement ps = conn.prepareStatement(sql);
							ps.setString(1, English);
							ps.setString(2, Korean);
							ps.setInt(3, 1); // list_id
							ps.executeUpdate() ;
						}
						JOptionPane.showMessageDialog(null, "단어를 등록 했습니다", "정보", JOptionPane.INFORMATION_MESSAGE);
						model.setRowCount(0);
					} catch (ClassNotFoundException | SQLException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		
	}
}
