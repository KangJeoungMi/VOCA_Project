package expj;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JSlider;
import java.awt.Choice;
import java.awt.Color;
import javax.swing.JLabel;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

public class ShowVoca extends JFrame {

	Connection conn;
	Statement st;
	PreparedStatement ps;
	ResultSet rs;
	ResultSetMetaData rsmd;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tblData;
	private JScrollPane scrollPane;
	private JButton btnNewButton;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowVoca frame = new ShowVoca();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ShowVoca() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 352, 353);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnLoadTable = new JButton("그룹 선택");
		btnLoadTable.setBounds(216, 10, 97, 23);
		contentPane.add(btnLoadTable);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(37, 43, 276, 210);
		contentPane.add(scrollPane);

		tblData = new JTable();
		scrollPane.setViewportView(tblData);
		tblData.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "korean", "english" }));

		btnNewButton = new JButton("메인으로");
		// 메인가는 버튼
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				wordmainFrame WM = new wordmainFrame();
				WM.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(34, 265, 279, 23);
		contentPane.add(btnNewButton);

		comboBox = new JComboBox();
		comboBox.setBounds(37, 10, 167, 23);
		contentPane.add(comboBox);

		btnLoadTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				vocalistTable();
			}
		});

	}

	// 테이블 업데이트 메서드
	private void vocalistTable() {
		// 데이터베이스 연동
		conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "ADAM", "1234");
			String sql = "SELECT * FROM words";

			st = conn.createStatement();
			rs = st.executeQuery(sql);
			rsmd = rs.getMetaData();

			while (rs.next()) {
				String KO = rs.getString(2);
				String EN = rs.getString(3);
				String[] row = { KO, EN };
				DefaultTableModel model = (DefaultTableModel) tblData.getModel();
				model.addRow(row);
			}
			st.close();
			conn.close();

		} catch (ClassNotFoundException | SQLException e1) {
			e1.printStackTrace();
		}
	}
	
	private void vocaCategory() {
		DefaultTableModel model = (DefaultTableModel) comboBox.getModel();
        model.setRowCount(0); // 테이블 초기화
	    // 데이터베이스 연동
	    conn = null;
	    PreparedStatement ps = null; // PreparedStatement 객체 초기화
	    try {
	        Class.forName("oracle.jdbc.driver.OracleDriver");
	        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "ADAM", "1234");
	        String sql = "SELECT * FROM word_lists";

	        ps = conn.prepareStatement(sql); // PreparedStatement로 변경
	        rs = ps.executeQuery();
	        rsmd = rs.getMetaData();

	        while (rs.next()) {
	           String voca_list = rs.getString("category");
	           String[] row = {voca_list};
               model.addRow(row); // 테이블에 행 추가
	        }

	        rs.close();
	        ps.close(); // PreparedStatement 닫기
	        conn.close();

	    } catch (ClassNotFoundException | SQLException e1) {
	        e1.printStackTrace();
	    }
	}
}
